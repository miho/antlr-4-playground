package org.antlr.v4.codegen.model;

import org.antlr.v4.codegen.OutputModelFactory;

public class BaseParseListenerFile extends ParseListenerFile {
	public BaseParseListenerFile(OutputModelFactory factory, String fileName) {
		super(factory, fileName);
	}
}

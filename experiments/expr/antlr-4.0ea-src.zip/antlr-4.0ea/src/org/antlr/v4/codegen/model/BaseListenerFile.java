package org.antlr.v4.codegen.model;

import org.antlr.v4.codegen.OutputModelFactory;

public class BaseListenerFile extends ListenerFile {
	public BaseListenerFile(OutputModelFactory factory, String fileName) {
		super(factory, fileName);
	}
}

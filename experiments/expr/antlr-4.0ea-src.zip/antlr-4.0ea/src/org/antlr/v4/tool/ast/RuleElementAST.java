package org.antlr.v4.tool.ast;

/** Tag indicated AST node is a rule element like token or rule ref. */
public interface RuleElementAST {
}

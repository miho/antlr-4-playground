package org.antlr.v4.codegen.model;

import org.antlr.v4.codegen.OutputModelFactory;

public class VisitorDispatchMethod extends DispatchMethod {
	public VisitorDispatchMethod(OutputModelFactory factory) {
		super(factory);
	}
}

package org.antlr.v4.codegen.model;

import org.antlr.v4.codegen.OutputModelFactory;

public class DispatchMethod extends OutputModelObject {
	public DispatchMethod(OutputModelFactory factory) {
		super(factory);
	}
}
